This is a learning project.

**to build the wheel**

python setup.py bdist_wheel 

**to pip install this from the repo_daniel folder run**

pip install -e .

**with dev requirements**
pip install -e .[dev]

**to actally install run**

**Sample Code**
```
from hello_world import say_hello
say_hello()
```

**Build this repo**

https://www.youtube.com/watch?v=GIF3LaRqgXo